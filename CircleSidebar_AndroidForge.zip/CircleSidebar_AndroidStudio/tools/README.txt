Use JADX locally to recover Java/Kotlin from the original APK. Example:
jadx -d jadx-output original.apk
Then merge the recovered source into app/src/main/java.
