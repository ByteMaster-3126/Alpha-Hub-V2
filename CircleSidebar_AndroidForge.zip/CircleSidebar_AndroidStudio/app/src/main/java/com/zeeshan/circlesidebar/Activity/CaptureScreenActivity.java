package com.zeeshan.circlesidebar.Activity;
public class CaptureScreenActivity extends android.app.Activity {}
