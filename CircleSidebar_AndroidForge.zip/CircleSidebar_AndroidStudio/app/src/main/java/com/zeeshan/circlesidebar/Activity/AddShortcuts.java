package com.zeeshan.circlesidebar.Activity;
public class AddShortcuts extends android.app.Activity {}
