package com.zeeshan.circlesidebar.Activity;
public class AddAppPairs extends android.app.Activity {}
