package com.zeeshan.circlesidebar.Services;
public class SidebarReceiver extends android.content.BroadcastReceiver { public void onReceive(android.content.Context c, android.content.Intent i) {} }
