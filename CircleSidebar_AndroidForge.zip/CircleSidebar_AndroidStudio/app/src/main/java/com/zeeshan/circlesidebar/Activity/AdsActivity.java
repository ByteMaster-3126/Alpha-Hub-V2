package com.zeeshan.circlesidebar.Activity;
public class AdsActivity extends android.app.Activity {}
