package com.zeeshan.circlesidebar.Activity;
public class Customize extends android.app.Activity {}
