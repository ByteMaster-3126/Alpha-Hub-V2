package com.zeeshan.circlesidebar;
public class MyApplication extends android.app.Application {}
