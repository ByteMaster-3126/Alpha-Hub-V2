package com.zeeshan.circlesidebar.Services;
public class SplitScreenService extends android.app.Service { public android.os.IBinder onBind(android.content.Intent i) {return null;} }
