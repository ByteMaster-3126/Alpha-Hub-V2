package com.zeeshan.circlesidebar.Activity;
public class DatabaseSettings extends android.app.Activity {}
