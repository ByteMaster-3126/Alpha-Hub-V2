package com.zeeshan.circlesidebar.Services;
public class SidebarService extends android.accessibilityservice.AccessibilityService { public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent e) {} public void onInterrupt() {} }
