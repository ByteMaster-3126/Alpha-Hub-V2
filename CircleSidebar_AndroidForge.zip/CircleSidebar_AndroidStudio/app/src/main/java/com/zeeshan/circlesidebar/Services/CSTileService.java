package com.zeeshan.circlesidebar.Services;
public class CSTileService extends android.service.quicksettings.TileService {}
