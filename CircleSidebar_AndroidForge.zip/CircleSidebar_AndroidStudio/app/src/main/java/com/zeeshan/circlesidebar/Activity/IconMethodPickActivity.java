package com.zeeshan.circlesidebar.Activity;
public class IconMethodPickActivity extends android.app.Activity {}
