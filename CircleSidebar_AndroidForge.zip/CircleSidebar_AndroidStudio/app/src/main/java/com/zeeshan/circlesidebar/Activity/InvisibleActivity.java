package com.zeeshan.circlesidebar.Activity;
public class InvisibleActivity extends android.app.Activity {}
