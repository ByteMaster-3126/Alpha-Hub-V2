package com.zeeshan.circlesidebar.Activity;
public class SplitActivity extends android.app.Activity {}
