package com.zeeshan.circlesidebar.Activity;
public class MainActivity extends android.app.Activity {}
