package com.zeeshan.circlesidebar.Activity;
public class LicenseCheckActivity extends android.app.Activity {}
