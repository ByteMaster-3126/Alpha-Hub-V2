package com.zeeshan.circlesidebar.Activity;
public class Settings extends android.app.Activity {}
