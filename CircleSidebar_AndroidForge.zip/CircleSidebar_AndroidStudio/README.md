# CircleSidebar — AndroidForge-ready project

Reconstructed Android project prepared from the CircleSidebar APK for use with AndroidForge / GitHub Actions.

## Build

Upload the ZIP to AndroidForge and choose `auto` first. AndroidForge detects Gradle projects and selects a compatible toolchain automatically.

The project uses:
- Android Gradle Plugin 8.6.1
- compileSdk 35
- minSdk 21
- targetSdk 27
- Java source stubs reconstructed from the APK
- extracted resources and native libraries

## Important

This is an APK reconstruction. The original Java/Kotlin source is not embedded in an APK, so recovered source is not guaranteed to match the original implementation exactly. The original DEX is retained under `app/src/main/assets/original/` for reference.
